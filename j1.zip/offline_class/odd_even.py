n = int(input("enter a number: "))
if n % 2 == 0:
    print(f"{n} % 2 = 0 => {n} is even")
else:
    print(f"{n} % 2 = 1 => {n} is odd")
