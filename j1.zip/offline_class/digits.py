number = int(input("enter a number: "))

# convert the number into a string and count the number of digits
number_str = str(number)
num_digits = len(number_str)

# Display the number of digits
print(f"the number {number} has {num_digits} digits.")

a = "alireza mohammadi"
print(len(a))