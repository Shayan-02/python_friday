n = int(input("enter a number: "))
if n >= 0:
    print(n)
else:
    print(-n)