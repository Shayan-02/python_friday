kg = int(input("enter a number: "))
g = kg * 1000
if kg >= 0:
    print(f"{kg} kg = {g} g")
else:
    print("please enter a valid number")