a = "alireza ahmadi"
b = "123456789"
print(a[0])
print(a[1])
print(a[2:5])
print(a[-1:-5:-2])
print(b[::-1])
print(len(a))
print(a[0:len(a)])
