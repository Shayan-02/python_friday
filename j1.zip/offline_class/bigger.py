n1 = int(input("enter first number: "))
n2 = int(input("enter second number: "))
if n1 > n2:
    print(f"{n1} > {n2} => first number is bigger than second number")
elif n2 > n1:
    print(f"{n2} > {n1} => second number is bigger than first number")
else:
    print(f"{n1} = {n2}")