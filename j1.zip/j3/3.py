sum = 0
for i in range(1, 6):
    num = int(input(f"enter number{i}: "))
    sum += num
    i += 1
print(f"sum: {sum}")
