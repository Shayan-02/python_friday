a = "ali mohammadi"
c = ["ali", 20, "rezaee", 2220]
print(c)
for i in a:
    print(i, end="")
print("\n")
print(a)

for mohammad in c:
    print(mohammad, end=" ")
