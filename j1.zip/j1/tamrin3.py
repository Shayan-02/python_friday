a = 10
b = 20
jam = a + b
tafrigh = a - b
zarb = a * b
taghsim = a / b

print("jam of", a, "and", b, "=", jam)
print("tafrigh of", a, "and", b, "=", tafrigh)
print("zarb of", a, "and", b, "=", zarb)
print("taghsim of", a, "and", b, "=", taghsim)

# --------------------------
number1 = int(input("enter number1: "))
number2 = int(input("enter number2: "))

jam2 = number1 + number2
tafrigh2 = number1 - number2
zarb2 = number1 * number2
taghsim2 = number1 / number2

print("sum of", number1, "and", number2, "=", jam2)
print("sub of", number1, "and", number2, "=", tafrigh2)
print("mul of", number1, "and", number2, "=", zarb)
print("div of", number1, "and", number2, "=", taghsim2)
