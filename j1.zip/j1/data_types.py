# int:
a = 1

# float:
b = 1.1

# string:
c = "hi"

# boolean
d = True
e = False

# none:
j = None

# --------------------

# list:
f = [1, 2]

# set
g = {1, 1, 2}

# tuple
h = (1, 2)

# dictionary
i = {1:1, 2: "2", 1:"1"}
