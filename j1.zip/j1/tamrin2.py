x = int(input("enter number1: "))
y = int(input("enter number2: "))

c = x + y

print(f'{x} + {y} = {c}')