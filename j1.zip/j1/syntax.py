# + . - . * . / . % . ** . // . = . == . != . %= ...
print('hi')
print(26)
a = 3

print(a)
b = 2
# result = a ** b
# result2 = 10 // 3
e = "ali"
f = 3 * e

x = input("c: ")
print(x)
print(type(x))

print('hi 26 {}'.format(a))

# print(f"result: {result}")
# print("result2: {}".format(result2))

# a //= b

y = "amir"
z = "mohammadi"

# t = float(input("number1: "))
# l = int(input('number2: '))
# avg = (t + l)/2
# print(avg)