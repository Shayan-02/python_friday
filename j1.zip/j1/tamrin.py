a = input("first name: ")
b = input("last name: ")
print("fullname:", a, b)