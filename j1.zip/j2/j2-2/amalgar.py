a = 10
b = 3
c = a + b
d = a - b
e = a * b
f = a / b
g = a ** b
h = a // b
i = a % b
print(a)
a += b
print(a)
