first_name = input("first name: ")
last_name = input("last name: ")
x = 5
z = 5
print(z)
print(float(z))
print(type(x))
y = int(input("enter a number: "))
print(type(y))
# print("your first name is:", first_name, "and your last name is:", last_name,"and your full name is:", first_name,last_name)