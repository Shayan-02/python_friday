firstName = "ali"
lastName = "mohammadi"
fullName = firstName + lastName
print(fullName)
print(firstName, lastName)
print("your first name is:", firstName, "and your last name is:", lastName,"and your full name is:", firstName,lastName)