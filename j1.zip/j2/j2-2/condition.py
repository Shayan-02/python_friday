# if .....:
#   test
# elif .....:
#   test2
# else:
#   end
# a = 1 ---> int, str, float
# a == 1 --->
a = int(input("enter a number: "))
b = int(input("enter a number: "))
if a == 1:
    print("your first number entered 1")
elif b == 2:
    print("your second number entered 2")
else:
    print("not correct")
