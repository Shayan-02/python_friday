print('ali')
# int:
print(1+2)
# string
print('1' + '2')
# ---------------------
a = 5
b = 6
c = 2.2
d = "ali"
print('ali')
print(d)
