number1 = int(input("enter number1: "))
number2 = int(input("enter number2: "))

jam2 = number1 + number2
tafrigh2 = number1 - number2
zarb2 = number1 * number2
taghsim2 = number1 / number2

print("sum of", number1, "and", number2, "is", jam2)
print(f'sum of {number1} and {number2} is {jam2}')
print("sum of {} and {} is {}".format(number1, number2, jam2))

a = True
b = not a
print(b)