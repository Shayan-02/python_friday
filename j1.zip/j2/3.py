a = int(input("a: "))
b = int(input("b: "))

result = a ** b
result2 = a // b
print(result)
print(result2)
e = "ali"
f = 3 * e
print(f"e: {e}")
print(f)

a %= b
print(a)